# Genetic Graph Coloring Algorithm

Run the programs as simple python programs with the python keyword. Python 3 is required to run these programs.
